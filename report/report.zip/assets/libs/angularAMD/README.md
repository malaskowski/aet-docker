# bower-angularAMD
bower repo for angularAMD

